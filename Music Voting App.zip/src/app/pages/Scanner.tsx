import { useState } from "react";
import { QrReader } from "react-qr-reader";
import { useNavigate } from "react-router";
import { ArrowLeft, QrCode } from "lucide-react";
import { Link } from "react-router";

export default function Scanner() {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  const handleScan = (result: any, error: any) => {
    if (result) {
      const eventId = result?.text;
      if (eventId) {
        navigate(`/vote?event=${eventId}`);
      }
    }
    if (error) {
      console.error(error);
      setError("Unable to access camera. Please check permissions.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 pb-8">
        <div className="max-w-md mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-purple-100 hover:text-white mb-4 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back</span>
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <QrCode className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Scan Event QR</h1>
          </div>
          <p className="text-purple-100 text-sm">
            Point your camera at the event QR code
          </p>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 py-8">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="aspect-square relative">
            <QrReader
              onResult={handleScan}
              constraints={{ facingMode: "environment" }}
              videoContainerStyle={{ paddingTop: "100%" }}
            />
          </div>
          {error && (
            <div className="p-4 bg-red-50 text-red-600 text-sm text-center">
              {error}
            </div>
          )}
        </div>

        <div className="mt-6 bg-white rounded-xl shadow-md p-4">
          <p className="text-sm text-gray-600 text-center">
            Position the QR code within the frame to scan automatically
          </p>
        </div>
      </div>
    </div>
  );
}
