import { useState } from "react";
import { Music2, TrendingUp, ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import { SongCard } from "../components/SongCard";
import { Song } from "../types/song";

const initialSongs: Song[] = [
  {
    id: "1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    album: "After Hours",
    votes: 142,
  },
  {
    id: "2",
    title: "Levitating",
    artist: "Dua Lipa",
    album: "Future Nostalgia",
    votes: 128,
  },
  {
    id: "3",
    title: "Save Your Tears",
    artist: "The Weeknd",
    album: "After Hours",
    votes: 115,
  },
  {
    id: "4",
    title: "Good 4 U",
    artist: "Olivia Rodrigo",
    album: "SOUR",
    votes: 98,
  },
  {
    id: "5",
    title: "Stay",
    artist: "The Kid LAROI & Justin Bieber",
    album: "F*ck Love 3: Over You",
    votes: 87,
  },
  {
    id: "6",
    title: "Peaches",
    artist: "Justin Bieber ft. Daniel Caesar",
    album: "Justice",
    votes: 76,
  },
  {
    id: "7",
    title: "Montero (Call Me By Your Name)",
    artist: "Lil Nas X",
    album: "Montero",
    votes: 64,
  },
  {
    id: "8",
    title: "Kiss Me More",
    artist: "Doja Cat ft. SZA",
    album: "Planet Her",
    votes: 52,
  },
];

export default function Voting() {
  const [songs, setSongs] = useState<Song[]>(
    initialSongs.sort((a, b) => b.votes - a.votes)
  );

  const handleVote = (songId: string, direction: "up" | "down") => {
    setSongs((prevSongs) => {
      const updatedSongs = prevSongs.map((song) => {
        if (song.id === songId) {
          return {
            ...song,
            votes: direction === "up" ? song.votes + 1 : song.votes - 1,
          };
        }
        return song;
      });
      return updatedSongs.sort((a, b) => b.votes - a.votes);
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 pb-8">
        <div className="max-w-md mx-auto">
          <Link to="/" className="inline-flex items-center gap-2 text-purple-100 hover:text-white mb-4 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back</span>
          </Link>
          <div className="flex items-center gap-3 mb-2">
            <Music2 className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Music Vote</h1>
          </div>
          <p className="text-purple-100 text-sm">
            Vote for your favorite tracks
          </p>
        </div>
      </div>

      <div className="max-w-md mx-auto -mt-4 px-6 mb-6">
        <div className="bg-white rounded-lg shadow-md p-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-purple-600" />
          <div>
            <p className="text-xs text-gray-600">Total Votes Cast</p>
            <p className="text-lg font-bold text-gray-900">
              {songs.reduce((sum, song) => sum + song.votes, 0)}
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto px-6 pb-8">
        <div className="flex flex-col gap-3">
          {songs.map((song, index) => (
            <div key={song.id} className="relative">
              <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-md z-10">
                {index + 1}
              </div>
              <SongCard song={song} onVote={handleVote} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
