import { ChevronUp, ChevronDown, Music } from "lucide-react";
import { Song } from "../types/song";

interface SongCardProps {
  song: Song;
  onVote: (songId: string, direction: "up" | "down") => void;
}

export function SongCard({ song, onVote }: SongCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 flex items-center gap-3">
      {/* Album Art */}
      <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-500 rounded-lg flex items-center justify-center flex-shrink-0">
        <Music className="w-8 h-8 text-white" />
      </div>

      {/* Song Info */}
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-gray-900 truncate">{song.title}</h3>
        <p className="text-sm text-gray-600 truncate">{song.artist}</p>
        <p className="text-xs text-gray-400 truncate">{song.album}</p>
      </div>

      {/* Voting Controls */}
      <div className="flex flex-col items-center gap-1 flex-shrink-0">
        <button
          onClick={() => onVote(song.id, "up")}
          className="p-1 rounded hover:bg-gray-100 transition-colors active:scale-95"
          aria-label="Upvote"
        >
          <ChevronUp className="w-6 h-6 text-gray-600" />
        </button>
        <span className="text-lg font-bold text-gray-900 min-w-[2rem] text-center">
          {song.votes}
        </span>
        <button
          onClick={() => onVote(song.id, "down")}
          className="p-1 rounded hover:bg-gray-100 transition-colors active:scale-95"
          aria-label="Downvote"
        >
          <ChevronDown className="w-6 h-6 text-gray-600" />
        </button>
      </div>
    </div>
  );
}
